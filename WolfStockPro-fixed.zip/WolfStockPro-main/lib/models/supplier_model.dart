class SupplierModel {
  final int? id;
  final String name;
  final String? contactPerson;
  final String? phone;
  final String? email;
  final String? address;

  SupplierModel({
    this.id,
    required this.name,
    this.contactPerson,
    this.phone,
    this.email,
    this.address,
  });

  factory SupplierModel.fromMap(Map<String, dynamic> map) {
    return SupplierModel(
      id: map['id'],
      name: map['company_name'],
      contactPerson: map['contact_name'],
      phone: map['phone'],
      email: map['email'],
      address: map['address'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'company_name': name,
      'contact_name': contactPerson,
      'phone': phone,
      'email': email,
      'address': address,
    };
  }
}
